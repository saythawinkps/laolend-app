import { useState } from 'react';

export default function LaoLendHome() {
  const [role, setRole] = useState(null);

  return (
    <div style={{ padding: '2rem', maxWidth: '800px', margin: '0 auto' }}>
      <h1>Welcome to LaoLend</h1>
      <p>A secure and transparent peer-to-peer lending platform made for Laos.</p>

      <div style={{ display: 'flex', gap: '1rem', marginTop: '2rem' }}>
        <div onClick={() => setRole('borrower')} style={{ padding: '1rem', border: '1px solid gray', cursor: 'pointer' }}>
          <h2>I Want to Borrow</h2>
          <p>Apply for personal or business loans easily.</p>
        </div>

        <div onClick={() => setRole('lender')} style={{ padding: '1rem', border: '1px solid gray', cursor: 'pointer' }}>
          <h2>I Want to Lend</h2>
          <p>Invest in borrowers and earn monthly interest.</p>
        </div>
      </div>

      {role && (
        <div style={{ marginTop: '2rem' }}>
          <h3>Continue as a {role}</h3>
          <button style={{ marginRight: '1rem' }}>Login</button>
          <button>Register</button>

          <div style={{ marginTop: '2rem' }}>
            {role === 'borrower' ? (
              <div>
                <h4>Borrower Dashboard</h4>
                <ul>
                  <li>Apply for a new loan</li>
                  <li>Track loan application status</li>
                  <li>View repayment schedule</li>
                </ul>
              </div>
            ) : (
              <div>
                <h4>Lender Dashboard</h4>
                <ul>
                  <li>Browse borrower loan requests</li>
                  <li>Track your investments</li>
                  <li>View interest earned</li>
                </ul>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}