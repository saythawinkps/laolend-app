import React from 'react';
import ReactDOM from 'react-dom/client';
import LaoLendHome from './LaoLendHome';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <LaoLendHome />
  </React.StrictMode>
);